# Procesamiento de Lenguaje Natural

Los ejercicios vistos en clase están en la carpeta Book_Examples y tienen la fecha de cuando se realizo.